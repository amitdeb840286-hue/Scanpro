# ScanPro — Steps 1 & 2

Contains: project setup (Clean Architecture folders, Riverpod, go_router, Material 3,
EN/BN localization) + camera, live edge detection, auto-capture, crop, filters.

## Setup
```bash
flutter create --org com.example --project-name scanpro .   # generates android/ and ios/
flutter pub get
flutter gen-l10n
flutter run
```
(`flutter create .` keeps the existing lib/ and pubspec.yaml.)

## Android
`android/app/build.gradle(.kts)`: set `minSdk = 24`.
`android/app/src/main/AndroidManifest.xml` (inside <manifest>):
```xml
<uses-permission android:name="android.permission.CAMERA"/>
<uses-feature android:name="android.hardware.camera" android:required="false"/>
```

## iOS
`ios/Runner/Info.plist`:
```xml
<key>NSCameraUsageDescription</key><string>ScanPro needs the camera to scan documents.</string>
<key>NSPhotoLibraryUsageDescription</key><string>ScanPro imports photos from your library.</string>
```
`ios/Podfile`: `platform :ios, '13.0'` and inside `post_install` enable the camera
permission macro for permission_handler:
```ruby
target.build_configurations.each do |config|
  config.build_settings['GCC_PREPROCESSOR_DEFINITIONS'] ||= ['$(inherited)', 'PERMISSION_CAMERA=1']
end
```

## Notes
- Flow: Scan -> Crop -> Filter -> page added to the batch strip.
- opencv_dart's API differs slightly between versions; if a call fails to compile,
  check the version pinned in pubspec.yaml against its changelog.
- Test: `flutter test` (geometry tests are pure Dart).

import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../presentation/crop/crop_screen.dart';
import '../../presentation/filter/filter_screen.dart';
import '../../presentation/home/home_screen.dart';
import '../../presentation/scan/scan_screen.dart';
import '../../presentation/settings/settings_screen.dart';
import '../../presentation/shell/main_shell.dart';
import '../../presentation/tools/tools_screen.dart';

final _rootKey = GlobalKey<NavigatorState>();

final routerProvider = Provider<GoRouter>((ref) {
  return GoRouter(
    navigatorKey: _rootKey,
    initialLocation: '/home',
    routes: [
      StatefulShellRoute.indexedStack(
        builder: (c, s, shell) => MainShell(shell: shell),
        branches: [
          StatefulShellBranch(routes: [GoRoute(path: '/home', builder: (c, s) => const HomeScreen())]),
          StatefulShellBranch(routes: [GoRoute(path: '/scan', builder: (c, s) => const ScanScreen())]),
          StatefulShellBranch(routes: [GoRoute(path: '/tools', builder: (c, s) => const ToolsScreen())]),
          StatefulShellBranch(routes: [GoRoute(path: '/settings', builder: (c, s) => const SettingsScreen())]),
        ],
      ),
      // Full-screen flow routes (no bottom nav). They pop with Uint8List? (JPEG).
      GoRoute(
        path: '/crop',
        parentNavigatorKey: _rootKey,
        builder: (c, s) => CropScreen(path: s.extra as String),
      ),
      GoRoute(
        path: '/filter',
        parentNavigatorKey: _rootKey,
        builder: (c, s) => FilterScreen(imageBytes: s.extra as Uint8List),
      ),
    ],
  );
});

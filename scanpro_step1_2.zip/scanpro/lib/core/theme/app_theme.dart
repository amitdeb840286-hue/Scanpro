import 'package:flutter/material.dart';

/// Material 3 light/dark themes.
class AppTheme {
  static const _seed = Color(0xFF1E6FEB);
  static ThemeData get light => _build(Brightness.light);
  static ThemeData get dark => _build(Brightness.dark);

  static ThemeData _build(Brightness b) => ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: _seed, brightness: b),
        appBarTheme: const AppBarTheme(centerTitle: false),
      );
}

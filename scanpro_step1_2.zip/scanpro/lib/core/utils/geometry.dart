import 'dart:ui';

/// Orders 4 points as [topLeft, topRight, bottomRight, bottomLeft].
List<Offset> orderCorners(List<Offset> p) {
  assert(p.length == 4);
  final bySum = [...p]..sort((a, b) => (a.dx + a.dy).compareTo(b.dx + b.dy));
  final byDiff = [...p]..sort((a, b) => (a.dy - a.dx).compareTo(b.dy - b.dx));
  return [bySum.first, byDiff.first, bySum.last, byDiff.last];
}

/// Rotates a normalized (0..1) point clockwise by [degrees] (0/90/180/270).
/// Used to map camera-sensor frame coordinates to the portrait preview.
Offset rotateNormalized(Offset p, int degrees) {
  switch (degrees % 360) {
    case 90:
      return Offset(1 - p.dy, p.dx);
    case 180:
      return Offset(1 - p.dx, 1 - p.dy);
    case 270:
      return Offset(p.dy, 1 - p.dx);
    default:
      return p;
  }
}

/// Largest per-corner distance between two quads (normalized units).
double maxCornerDelta(List<Offset> a, List<Offset> b) {
  var m = 0.0;
  for (var i = 0; i < 4; i++) {
    final d = (a[i] - b[i]).distance;
    if (d > m) m = d;
  }
  return m;
}

/// Default crop quad: the image inset by [inset] on every side.
List<Offset> defaultQuad({double inset = 0.08}) => [
      Offset(inset, inset),
      Offset(1 - inset, inset),
      Offset(1 - inset, 1 - inset),
      Offset(inset, 1 - inset),
    ];

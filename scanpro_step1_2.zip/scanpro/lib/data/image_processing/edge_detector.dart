import 'dart:isolate';
import 'dart:typed_data';
import 'dart:ui';
import 'package:opencv_dart/opencv_dart.dart' as cv;
import '../../core/utils/geometry.dart';

/// Raw first plane of a camera frame (sendable to an isolate).
class FrameData {
  FrameData({
    required this.bytes,
    required this.width,
    required this.height,
    required this.bytesPerRow,
    required this.bytesPerPixel,
  });
  final Uint8List bytes;
  final int width, height, bytesPerRow, bytesPerPixel;
}

/// Finds the largest convex 4-point contour. Returns normalized corners
/// ordered TL, TR, BR, BL — or null when no document is found.
List<Offset>? _detect(cv.Mat gray) {
  final scale = 500 / (gray.cols > gray.rows ? gray.cols : gray.rows);
  final small = scale < 1 ? cv.resize(gray, (0, 0), fx: scale, fy: scale) : gray.clone();

  final blur = cv.gaussianBlur(small, (5, 5), 0);
  final edges = cv.canny(blur, 50, 150);
  final kernel = cv.getStructuringElement(cv.MORPH_RECT, (5, 5));
  final closed = cv.dilate(edges, kernel);
  final (contours, _) = cv.findContours(closed, cv.RETR_LIST, cv.CHAIN_APPROX_SIMPLE);

  final imgArea = (small.cols * small.rows).toDouble();
  List<Offset>? best;
  var bestArea = 0.0;
  for (var i = 0; i < contours.length; i++) {
    final c = contours[i];
    final area = cv.contourArea(c);
    if (area < imgArea * 0.15 || area <= bestArea) continue;
    final approx = cv.approxPolyDP(c, 0.02 * cv.arcLength(c, true), true);
    if (approx.length == 4 && cv.isContourConvex(approx)) {
      best = [
        for (var j = 0; j < 4; j++)
          Offset(approx[j].x / small.cols, approx[j].y / small.rows)
      ];
      bestArea = area;
    }
  }
  return best == null ? null : orderCorners(best);
}

/// Detect from a live camera frame (runs in a background isolate).
Future<List<Offset>?> detectFromFrame(FrameData f) => Isolate.run(() {
      final gray = Uint8List(f.width * f.height);
      for (var r = 0; r < f.height; r++) {
        final src = r * f.bytesPerRow;
        final dst = r * f.width;
        if (f.bytesPerPixel == 1) {
          gray.setRange(dst, dst + f.width, f.bytes, src); // Android Y plane
        } else {
          for (var c = 0; c < f.width; c++) {
            gray[dst + c] = f.bytes[src + c * f.bytesPerPixel + 1]; // iOS BGRA: G ~ luma
          }
        }
      }
      final mat = cv.Mat.fromList(f.height, f.width, cv.MatType.CV_8UC1, gray);
      return _detect(mat);
    });

/// Detect from a saved image file (runs in a background isolate).
Future<List<Offset>?> detectFromFile(String path) => Isolate.run(() {
      final mat = cv.imread(path, flags: cv.IMREAD_GRAYSCALE);
      if (mat.isEmpty) return null;
      return _detect(mat);
    });

import 'dart:isolate';
import 'dart:math' as math;
import 'dart:typed_data';
import 'dart:ui';
import 'package:opencv_dart/opencv_dart.dart' as cv;

enum ScanFilter { original, grayscale, blackWhite, magicColor, shadowRemoval, sharpen }

/// Plain, sendable edit description.
class EditParams {
  const EditParams({
    this.filter = ScanFilter.original,
    this.brightness = 0, // -100..100
    this.contrast = 1, // 0.5..2
    this.saturation = 1, // 0..2
    this.quarterTurns = 0, // clockwise 90° steps
    this.flipH = false,
  });
  final ScanFilter filter;
  final double brightness, contrast, saturation;
  final int quarterTurns;
  final bool flipH;

  EditParams copyWith({
    ScanFilter? filter,
    double? brightness,
    double? contrast,
    double? saturation,
    int? quarterTurns,
    bool? flipH,
  }) =>
      EditParams(
        filter: filter ?? this.filter,
        brightness: brightness ?? this.brightness,
        contrast: contrast ?? this.contrast,
        saturation: saturation ?? this.saturation,
        quarterTurns: quarterTurns ?? this.quarterTurns,
        flipH: flipH ?? this.flipH,
      );

  /// One-tap "auto enhance" preset.
  static const autoEnhance =
      EditParams(filter: ScanFilter.magicColor, contrast: 1.1, brightness: 5);
}

/// Perspective-corrects [path] using normalized [quad] (TL,TR,BR,BL). Returns JPEG bytes.
Future<Uint8List> warpFromFile(String path, List<Offset> quad) => Isolate.run(() {
      // imread applies EXIF orientation, matching what the user saw on screen.
      final src = cv.imread(path);
      final w = src.cols.toDouble(), h = src.rows.toDouble();
      final p = [for (final q in quad) cv.Point2f(q.dx * w, q.dy * h)];
      double dist(cv.Point2f a, cv.Point2f b) =>
          math.sqrt(math.pow(a.x - b.x, 2) + math.pow(a.y - b.y, 2));
      final outW = math.max(dist(p[0], p[1]), dist(p[3], p[2])).round().clamp(1, 6000);
      final outH = math.max(dist(p[0], p[3]), dist(p[1], p[2])).round().clamp(1, 6000);
      final dst = cv.VecPoint2f.fromList([
        cv.Point2f(0, 0),
        cv.Point2f(outW - 1.0, 0),
        cv.Point2f(outW - 1.0, outH - 1.0),
        cv.Point2f(0, outH - 1.0),
      ]);
      final m = cv.getPerspectiveTransform(cv.VecPoint2f.fromList(p), dst);
      final out = cv.warpPerspective(src, m, (outW, outH));
      return cv.imencode('.jpg', out).$2;
    });

/// Downscales JPEG bytes so the longest side is at most [maxSide] (for fast previews).
Future<Uint8List> makePreview(Uint8List jpeg, {int maxSide = 1100}) => Isolate.run(() {
      final m = cv.imdecode(jpeg, cv.IMREAD_COLOR);
      final s = maxSide / math.max(m.cols, m.rows);
      if (s >= 1) return jpeg;
      return cv.imencode('.jpg', cv.resize(m, (0, 0), fx: s, fy: s)).$2;
    });

/// Applies filter + adjustments + rotate/flip. Returns JPEG bytes.
Future<Uint8List> applyEdits(Uint8List jpeg, EditParams p, {int quality = 92}) =>
    Isolate.run(() {
      var m = cv.imdecode(jpeg, cv.IMREAD_COLOR);

      switch (p.filter) {
        case ScanFilter.original:
          break;
        case ScanFilter.grayscale:
          m = cv.cvtColor(cv.cvtColor(m, cv.COLOR_BGR2GRAY), cv.COLOR_GRAY2BGR);
          break;
        case ScanFilter.blackWhite:
          final g = cv.cvtColor(m, cv.COLOR_BGR2GRAY);
          final t = cv.adaptiveThreshold(
              g, 255, cv.ADAPTIVE_THRESH_GAUSSIAN_C, cv.THRESH_BINARY, 31, 12);
          m = cv.cvtColor(t, cv.COLOR_GRAY2BGR);
          break;
        case ScanFilter.shadowRemoval:
          m = _removeShadow(m);
          break;
        case ScanFilter.magicColor:
          m = _removeShadow(m).convertTo(cv.MatType.CV_8UC3, alpha: 1.15, beta: 8);
          break;
        case ScanFilter.sharpen:
          final blur = cv.gaussianBlur(m, (0, 0), 3);
          m = cv.addWeighted(m, 1.6, blur, -0.6, 0);
          break;
      }

      if (p.contrast != 1 || p.brightness != 0) {
        m = m.convertTo(cv.MatType.CV_8UC3, alpha: p.contrast, beta: p.brightness);
      }
      if (p.saturation != 1) {
        final hsv = cv.cvtColor(m, cv.COLOR_BGR2HSV);
        final ch = cv.split(hsv);
        final s = ch[1].convertTo(cv.MatType.CV_8UC1, alpha: p.saturation);
        m = cv.cvtColor(
            cv.merge(cv.VecMat.fromList([ch[0], s, ch[2]])), cv.COLOR_HSV2BGR);
      }

      switch (p.quarterTurns % 4) {
        case 1:
          m = cv.rotate(m, cv.ROTATE_90_CLOCKWISE);
          break;
        case 2:
          m = cv.rotate(m, cv.ROTATE_180);
          break;
        case 3:
          m = cv.rotate(m, cv.ROTATE_90_COUNTERCLOCKWISE);
          break;
      }
      if (p.flipH) m = cv.flip(m, 1);

      return cv.imencode('.jpg', m, params: cv.VecI32.fromList([cv.IMWRITE_JPEG_QUALITY, quality])).$2;
    });

/// Divides out the page background (dilate + median blur) to flatten shadows.
cv.Mat _removeShadow(cv.Mat src) {
  final k = cv.getStructuringElement(cv.MORPH_RECT, (7, 7));
  final bg = cv.medianBlur(cv.dilate(src, k), 21);
  final diff = cv.bitwiseNOT(cv.absDiff(src, bg));
  return cv.normalize(diff, diff, alpha: 0, beta: 255, normType: cv.NORM_MINMAX);
}

/// One processed page of the document currently being scanned.
class ScanPage {
  const ScanPage({required this.id, required this.path});
  final String id;
  final String path; // processed JPEG on disk
}

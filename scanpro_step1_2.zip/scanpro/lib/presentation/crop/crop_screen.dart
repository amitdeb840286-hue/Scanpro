import 'dart:io';
import 'dart:typed_data';
import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../core/utils/geometry.dart';
import '../../data/image_processing/edge_detector.dart';
import '../../data/image_processing/image_processor.dart';
import '../../l10n/app_localizations.dart';

/// Perspective crop: auto-detected corners, draggable handles, magnifier.
/// Pops with the warped JPEG (after the filter screen) or null if cancelled.
class CropScreen extends StatefulWidget {
  const CropScreen({super.key, required this.path});
  final String path;
  @override
  State<CropScreen> createState() => _CropScreenState();
}

class _CropScreenState extends State<CropScreen> {
  ui.Image? _img;
  List<Offset> _q = defaultQuad();
  int? _drag;
  bool _busy = false, _failed = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final bytes = await File(widget.path).readAsBytes();
      final img = await decodeImageFromList(bytes);
      final quad = await detectFromFile(widget.path);
      if (!mounted) return;
      setState(() {
        _img = img;
        if (quad != null) _q = quad;
      });
    } catch (_) {
      if (mounted) setState(() => _failed = true);
    }
  }

  Future<void> _next() async {
    setState(() => _busy = true);
    try {
      final warped = await warpFromFile(widget.path, _q);
      if (!mounted) return;
      final res = await context.push<Uint8List>('/filter', extra: warped);
      if (res != null && mounted) context.pop(res);
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text(AppLocalizations.of(context).errorGeneric)));
      }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final l = AppLocalizations.of(context);
    return Scaffold(
      appBar: AppBar(
        title: Text(l.cropTitle),
        actions: [
          TextButton(
            onPressed: _img == null || _busy ? null : () => setState(() => _q = defaultQuad(inset: 0)),
            child: const Icon(Icons.crop_free),
          ),
          TextButton(onPressed: _img == null || _busy ? null : _next, child: Text(l.next)),
        ],
      ),
      body: _failed
          ? Center(child: Text(l.errorGeneric))
          : _img == null
              ? const Center(child: CircularProgressIndicator())
              : Stack(children: [
                  Positioned.fill(child: LayoutBuilder(builder: _editor)),
                  if (_busy) const Positioned.fill(child: ColoredBox(color: Colors.black38, child: Center(child: CircularProgressIndicator()))),
                ]),
    );
  }

  Widget _editor(BuildContext context, BoxConstraints box) {
    final ar = _img!.width / _img!.height;
    var w = box.maxWidth - 48, h = w / ar;
    if (h > box.maxHeight - 48) {
      h = box.maxHeight - 48;
      w = h * ar;
    }
    final scheme = Theme.of(context).colorScheme;
    Offset px(Offset n) => Offset(n.dx * w, n.dy * h);

    return Center(
      child: SizedBox(
        width: w,
        height: h,
        child: Stack(clipBehavior: Clip.none, children: [
          Positioned.fill(child: Image.file(File(widget.path), fit: BoxFit.fill, cacheWidth: 1600)),
          Positioned.fill(child: CustomPaint(painter: _CropPainter(_q, scheme.primary))),
          for (var i = 0; i < 4; i++)
            Positioned(
              left: px(_q[i]).dx - 24,
              top: px(_q[i]).dy - 24,
              child: GestureDetector(
                behavior: HitTestBehavior.opaque,
                onPanStart: (_) => setState(() => _drag = i),
                onPanUpdate: (d) => setState(() {
                  final n = _q[i] + Offset(d.delta.dx / w, d.delta.dy / h);
                  _q[i] = Offset(n.dx.clamp(0.0, 1.0), n.dy.clamp(0.0, 1.0));
                }),
                onPanEnd: (_) => setState(() => _drag = null),
                child: SizedBox(
                  width: 48,
                  height: 48,
                  child: Center(
                    child: Container(
                      width: 22,
                      height: 22,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: scheme.primary,
                        border: Border.all(color: Colors.white, width: 2),
                      ),
                    ),
                  ),
                ),
              ),
            ),
          // Magnifier shown above the finger while dragging a corner.
          if (_drag != null)
            Positioned(
              left: px(_q[_drag!]).dx - 50,
              top: px(_q[_drag!]).dy - 150,
              child: const IgnorePointer(
                child: RawMagnifier(
                  size: Size(100, 100),
                  magnificationScale: 2.2,
                  focalPointOffset: Offset(0, 100),
                  decoration: MagnifierDecoration(
                    shape: CircleBorder(side: BorderSide(color: Colors.white, width: 3)),
                  ),
                ),
              ),
            ),
        ]),
      ),
    );
  }
}

class _CropPainter extends CustomPainter {
  _CropPainter(this.q, this.color);
  final List<Offset> q;
  final Color color;
  @override
  void paint(Canvas canvas, Size s) {
    final pts = [for (final p in q) Offset(p.dx * s.width, p.dy * s.height)];
    final path = Path()..addPolygon(pts, true);
    final dim = Path.combine(PathOperation.difference, Path()..addRect(Offset.zero & s), path);
    canvas.drawPath(dim, Paint()..color = Colors.black54);
    canvas.drawPath(path, Paint()..color = color..style = PaintingStyle.stroke..strokeWidth = 3);
  }

  @override
  bool shouldRepaint(_CropPainter old) => true;
}

import 'dart:async';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../data/image_processing/image_processor.dart';
import '../../l10n/app_localizations.dart';

/// Filters + adjustments. Previews on a downscaled copy; the final image is
/// rendered from the full-resolution bytes. Pops with final JPEG bytes.
class FilterScreen extends StatefulWidget {
  const FilterScreen({super.key, required this.imageBytes});
  final Uint8List imageBytes;
  @override
  State<FilterScreen> createState() => _FilterScreenState();
}

class _FilterScreenState extends State<FilterScreen> {
  Uint8List? _smallSource, _shown;
  EditParams _p = const EditParams();
  int _token = 0; // drops stale preview results
  Timer? _debounce;
  bool _saving = false;

  @override
  void initState() {
    super.initState();
    makePreview(widget.imageBytes).then((s) {
      if (!mounted) return;
      _smallSource = s;
      setState(() => _shown = s);
    });
  }

  @override
  void dispose() {
    _debounce?.cancel();
    super.dispose();
  }

  void _update(EditParams p, {bool immediate = false}) {
    setState(() => _p = p);
    _debounce?.cancel();
    _debounce = Timer(immediate ? Duration.zero : const Duration(milliseconds: 150), () async {
      final src = _smallSource;
      if (src == null) return;
      final t = ++_token;
      final out = await applyEdits(src, _p, quality: 80);
      if (mounted && t == _token) setState(() => _shown = out);
    });
  }

  Future<void> _done() async {
    setState(() => _saving = true);
    try {
      final out = await applyEdits(widget.imageBytes, _p);
      if (mounted) context.pop(out);
    } catch (_) {
      if (mounted) {
        setState(() => _saving = false);
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text(AppLocalizations.of(context).errorGeneric)));
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final l = AppLocalizations.of(context);
    final names = {
      ScanFilter.original: l.filterOriginal,
      ScanFilter.grayscale: l.filterGrayscale,
      ScanFilter.blackWhite: l.filterBlackWhite,
      ScanFilter.magicColor: l.filterMagicColor,
      ScanFilter.shadowRemoval: l.filterShadow,
      ScanFilter.sharpen: l.filterSharpen,
    };
    return Scaffold(
      appBar: AppBar(
        title: Text(l.filterTitle),
        actions: [
          TextButton(onPressed: _saving || _shown == null ? null : _done, child: Text(l.done)),
        ],
      ),
      body: Column(children: [
        Expanded(
          child: Stack(children: [
            Positioned.fill(
              child: _shown == null
                  ? const Center(child: CircularProgressIndicator())
                  : Padding(
                      padding: const EdgeInsets.all(12),
                      child: Image.memory(_shown!, fit: BoxFit.contain, gaplessPlayback: true),
                    ),
            ),
            if (_saving)
              const Positioned.fill(child: ColoredBox(color: Colors.black38, child: Center(child: CircularProgressIndicator()))),
          ]),
        ),
        SizedBox(
          height: 48,
          child: ListView(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 12),
            children: [
              for (final f in ScanFilter.values)
                Padding(
                  padding: const EdgeInsets.only(right: 8),
                  child: ChoiceChip(
                    label: Text(names[f]!),
                    selected: _p.filter == f,
                    onSelected: (_) => _update(_p.copyWith(filter: f), immediate: true),
                  ),
                ),
            ],
          ),
        ),
        _slider(l.brightness, _p.brightness, -100, 100, (v) => _update(_p.copyWith(brightness: v))),
        _slider(l.contrast, _p.contrast, 0.5, 2, (v) => _update(_p.copyWith(contrast: v))),
        _slider(l.saturation, _p.saturation, 0, 2, (v) => _update(_p.copyWith(saturation: v))),
        Padding(
          padding: const EdgeInsets.fromLTRB(8, 0, 8, 8),
          child: Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
            IconButton(icon: const Icon(Icons.rotate_left),
                onPressed: () => _update(_p.copyWith(quarterTurns: (_p.quarterTurns + 3) % 4), immediate: true)),
            IconButton(icon: const Icon(Icons.rotate_right),
                onPressed: () => _update(_p.copyWith(quarterTurns: (_p.quarterTurns + 1) % 4), immediate: true)),
            IconButton(icon: const Icon(Icons.flip),
                onPressed: () => _update(_p.copyWith(flipH: !_p.flipH), immediate: true)),
            FilledButton.tonalIcon(
              icon: const Icon(Icons.auto_fix_high),
              label: Text(l.autoEnhance),
              onPressed: () => _update(EditParams.autoEnhance, immediate: true),
            ),
          ]),
        ),
      ]),
    );
  }

  Widget _slider(String label, double v, double min, double max, ValueChanged<double> on) =>
      Row(children: [
        SizedBox(width: 100, child: Padding(padding: const EdgeInsets.only(left: 16), child: Text(label))),
        Expanded(child: Slider(value: v.clamp(min, max), min: min, max: max, onChanged: on)),
      ]);
}

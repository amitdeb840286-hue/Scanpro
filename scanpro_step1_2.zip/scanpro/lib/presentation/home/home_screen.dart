import 'package:flutter/material.dart';
import '../../l10n/app_localizations.dart';

/// Placeholder: the real library (SQLite) arrives in Step 3.
class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});
  @override
  Widget build(BuildContext context) {
    final l = AppLocalizations.of(context);
    return Scaffold(
      appBar: AppBar(title: Text(l.appName)),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(32),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Icon(Icons.folder_open, size: 72, color: Theme.of(context).colorScheme.outline),
            const SizedBox(height: 16),
            Text(l.homeEmpty, textAlign: TextAlign.center),
          ]),
        ),
      ),
    );
  }
}

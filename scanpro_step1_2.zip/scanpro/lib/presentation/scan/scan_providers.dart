import 'dart:io';
import 'dart:typed_data';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:path_provider/path_provider.dart';
import '../../domain/entities/scan_page.dart';

/// Pages of the batch currently being scanned (persisted to DB in Step 3).
class PagesNotifier extends Notifier<List<ScanPage>> {
  @override
  List<ScanPage> build() => const [];

  Future<void> addBytes(Uint8List jpeg) async {
    final dir = await getTemporaryDirectory();
    final id = DateTime.now().microsecondsSinceEpoch.toString();
    final file = File('${dir.path}/page_$id.jpg');
    await file.writeAsBytes(jpeg, flush: true);
    state = [...state, ScanPage(id: id, path: file.path)];
  }

  void clear() => state = const [];
}

final pagesProvider = NotifierProvider<PagesNotifier, List<ScanPage>>(PagesNotifier.new);

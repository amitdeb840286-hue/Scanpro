import 'dart:io';
import 'dart:typed_data';
import 'package:camera/camera.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:image_picker/image_picker.dart';
import 'package:permission_handler/permission_handler.dart';
import '../../core/utils/geometry.dart';
import '../../data/image_processing/edge_detector.dart';
import '../../l10n/app_localizations.dart';
import 'scan_providers.dart';

/// Live camera with real-time document detection, auto-capture, flash,
/// tap-to-focus, pinch zoom, gallery import and a batch thumbnail strip.
class ScanScreen extends ConsumerStatefulWidget {
  const ScanScreen({super.key});
  @override
  ConsumerState<ScanScreen> createState() => _ScanScreenState();
}

class _ScanScreenState extends ConsumerState<ScanScreen> with WidgetsBindingObserver {
  CameraController? _cam;
  bool _denied = false, _error = false;
  bool _detecting = false, _capturing = false, _autoCapture = true;
  List<Offset>? _quad, _lastQuad;
  int _stable = 0;
  DateTime _lastFrame = DateTime.fromMillisecondsSinceEpoch(0);
  double _minZoom = 1, _maxZoom = 1, _zoom = 1, _baseZoom = 1;
  FlashMode _flash = FlashMode.off;
  Offset? _focusPoint;

  static const _stableFramesNeeded = 4; // ~1.2 s at 300 ms/frame
  static const _stableTolerance = 0.025; // normalized units

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _init();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _cam?.dispose();
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState s) {
    final c = _cam;
    if (c == null || !c.value.isInitialized) return;
    if (s == AppLifecycleState.inactive) {
      c.dispose();
      _cam = null;
    } else if (s == AppLifecycleState.resumed) {
      _init();
    }
  }

  Future<void> _init() async {
    setState(() {
      _denied = false;
      _error = false;
    });
    final status = await Permission.camera.request();
    if (!status.isGranted) {
      if (mounted) setState(() => _denied = true);
      return;
    }
    try {
      final cams = await availableCameras();
      final back = cams.firstWhere((c) => c.lensDirection == CameraLensDirection.back,
          orElse: () => cams.first);
      final c = CameraController(
        back,
        ResolutionPreset.high,
        enableAudio: false,
        imageFormatGroup:
            Platform.isAndroid ? ImageFormatGroup.yuv420 : ImageFormatGroup.bgra8888,
      );
      await c.initialize();
      await c.setFlashMode(_flash);
      _minZoom = await c.getMinZoomLevel();
      _maxZoom = await c.getMaxZoomLevel();
      _zoom = _minZoom;
      await c.startImageStream(_onFrame);
      if (!mounted) {
        await c.dispose();
        return;
      }
      setState(() => _cam = c);
    } on CameraException {
      if (mounted) setState(() => _error = true);
    }
  }

  Future<void> _onFrame(CameraImage img) async {
    final now = DateTime.now();
    if (_detecting || _capturing || now.difference(_lastFrame).inMilliseconds < 300) return;
    _lastFrame = now;
    _detecting = true;
    try {
      final plane = img.planes[0];
      final raw = await detectFromFrame(FrameData(
        bytes: plane.bytes,
        width: img.width,
        height: img.height,
        bytesPerRow: plane.bytesPerRow,
        bytesPerPixel: plane.bytesPerPixel ?? 1,
      ));
      final rot = _cam?.description.sensorOrientation ?? 90;
      final quad = raw == null
          ? null
          : orderCorners([for (final p in raw) rotateNormalized(p, rot)]);

      if (quad != null && _lastQuad != null && maxCornerDelta(quad, _lastQuad!) < _stableTolerance) {
        _stable++;
      } else {
        _stable = 0;
      }
      _lastQuad = quad;
      if (mounted) setState(() => _quad = quad);

      if (_autoCapture && quad != null && _stable >= _stableFramesNeeded) {
        _stable = 0;
        await _capture();
      }
    } catch (_) {
      // A failed frame is not fatal; the next frame retries.
    } finally {
      _detecting = false;
    }
  }

  Future<void> _capture() async {
    final c = _cam;
    if (c == null || _capturing || !c.value.isInitialized) return;
    _capturing = true;
    try {
      await c.stopImageStream();
      final file = await c.takePicture();
      if (!mounted) return;
      await _editFlow(file.path);
    } on CameraException {
      if (mounted) _snack(AppLocalizations.of(context).errorGeneric);
    } finally {
      _capturing = false;
      _lastQuad = null;
      _stable = 0;
      if (mounted && _cam != null && !_cam!.value.isStreamingImages) {
        try {
          await _cam!.startImageStream(_onFrame);
        } on CameraException {/* ignore */}
      }
    }
  }

  /// crop -> filter -> add to batch.
  Future<void> _editFlow(String path) async {
    final result = await context.push<Uint8List>('/crop', extra: path);
    if (result != null) await ref.read(pagesProvider.notifier).addBytes(result);
  }

  Future<void> _pickGallery() async {
    final files = await ImagePicker().pickMultiImage();
    for (final f in files) {
      if (!mounted) return;
      await _editFlow(f.path);
    }
  }

  Future<void> _toggleFlash() async {
    final next = _flash == FlashMode.off ? FlashMode.torch : FlashMode.off;
    await _cam?.setFlashMode(next);
    setState(() => _flash = next);
  }

  Future<void> _focusAt(Offset local, Size size) async {
    final c = _cam;
    if (c == null) return;
    final p = Offset(local.dx / size.width, local.dy / size.height);
    setState(() => _focusPoint = local);
    try {
      await c.setFocusPoint(p);
      await c.setExposurePoint(p);
    } on CameraException {/* not supported on some devices */}
    Future.delayed(const Duration(seconds: 1), () {
      if (mounted) setState(() => _focusPoint = null);
    });
  }

  void _snack(String m) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));

  @override
  Widget build(BuildContext context) {
    final l = AppLocalizations.of(context);
    if (_denied) return _Message(text: l.cameraDenied, action: l.openSettings, onTap: openAppSettings);
    if (_error) return _Message(text: l.errorGeneric, action: l.retry, onTap: _init);
    final c = _cam;
    if (c == null || !c.value.isInitialized) {
      return const Scaffold(backgroundColor: Colors.black, body: Center(child: CircularProgressIndicator()));
    }
    final pages = ref.watch(pagesProvider);

    return Scaffold(
      backgroundColor: Colors.black,
      body: SafeArea(
        child: Column(children: [
          _topBar(l, pages.length),
          Expanded(
            child: Center(
              child: AspectRatio(
                aspectRatio: 1 / c.value.aspectRatio,
                child: LayoutBuilder(builder: (ctx, box) {
                  final size = box.biggest;
                  return GestureDetector(
                    onTapUp: (d) => _focusAt(d.localPosition, size),
                    onScaleStart: (_) => _baseZoom = _zoom,
                    onScaleUpdate: (d) {
                      _zoom = (_baseZoom * d.scale).clamp(_minZoom, _maxZoom);
                      c.setZoomLevel(_zoom);
                    },
                    child: Stack(fit: StackFit.expand, children: [
                      CameraPreview(c),
                      CustomPaint(painter: _QuadPainter(_quad, Theme.of(context).colorScheme.primary)),
                      if (_focusPoint != null)
                        Positioned(
                          left: _focusPoint!.dx - 28,
                          top: _focusPoint!.dy - 28,
                          child: Container(
                            width: 56,
                            height: 56,
                            decoration: BoxDecoration(
                              border: Border.all(color: Colors.yellow, width: 2),
                              borderRadius: BorderRadius.circular(8),
                            ),
                          ),
                        ),
                      Positioned(
                        bottom: 12,
                        left: 0,
                        right: 0,
                        child: Text(l.scanHint,
                            textAlign: TextAlign.center,
                            style: const TextStyle(color: Colors.white, shadows: [Shadow(blurRadius: 4)])),
                      ),
                    ]),
                  );
                }),
              ),
            ),
          ),
          _thumbStrip(pages),
          _bottomBar(l, pages.length),
        ]),
      ),
    );
  }

  Widget _topBar(AppLocalizations l, int count) => Padding(
        padding: const EdgeInsets.symmetric(horizontal: 8),
        child: Row(children: [
          IconButton(
            color: Colors.white,
            icon: Icon(_flash == FlashMode.torch ? Icons.flash_on : Icons.flash_off),
            onPressed: _toggleFlash,
          ),
          FilterChip(
            label: Text(l.autoCapture),
            selected: _autoCapture,
            onSelected: (v) => setState(() => _autoCapture = v),
          ),
          const Spacer(),
          if (count > 0)
            Chip(avatar: const Icon(Icons.layers, size: 18), label: Text(l.pageCount(count))),
        ]),
      );

  Widget _thumbStrip(List pages) => SizedBox(
        height: pages.isEmpty ? 0 : 64,
        child: ListView.separated(
          scrollDirection: Axis.horizontal,
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
          itemCount: pages.length,
          separatorBuilder: (_, __) => const SizedBox(width: 8),
          itemBuilder: (_, i) => ClipRRect(
            borderRadius: BorderRadius.circular(6),
            child: Image.file(File(pages[i].path), width: 44, fit: BoxFit.cover, cacheWidth: 150),
          ),
        ),
      );

  Widget _bottomBar(AppLocalizations l, int count) => Padding(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 12),
        child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          IconButton(
              iconSize: 32, color: Colors.white, tooltip: l.galleryImport,
              icon: const Icon(Icons.photo_library_outlined), onPressed: _pickGallery),
          GestureDetector(
            onTap: _capture,
            child: Container(
              width: 72,
              height: 72,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: Colors.white,
                border: Border.all(color: Colors.white54, width: 6),
              ),
            ),
          ),
          SizedBox(
            width: 56,
            child: count == 0
                ? null
                : FilledButton(
                    onPressed: () => _snack(l.exportSoon), // export lands in Step 3
                    child: Text(l.done),
                  ),
          ),
        ]),
      );
}

class _QuadPainter extends CustomPainter {
  _QuadPainter(this.quad, this.color);
  final List<Offset>? quad;
  final Color color;

  @override
  void paint(Canvas canvas, Size size) {
    final q = quad;
    if (q == null) return;
    final pts = [for (final p in q) Offset(p.dx * size.width, p.dy * size.height)];
    final path = Path()..addPolygon(pts, true);
    canvas.drawPath(path, Paint()..color = color.withOpacity(0.25));
    canvas.drawPath(
        path,
        Paint()
          ..color = color
          ..style = PaintingStyle.stroke
          ..strokeWidth = 3);
  }

  @override
  bool shouldRepaint(_QuadPainter old) => old.quad != quad;
}

class _Message extends StatelessWidget {
  const _Message({required this.text, required this.action, required this.onTap});
  final String text, action;
  final VoidCallback onTap;
  @override
  Widget build(BuildContext context) => Scaffold(
        body: Center(
          child: Padding(
            padding: const EdgeInsets.all(32),
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              Text(text, textAlign: TextAlign.center),
              const SizedBox(height: 16),
              FilledButton(onPressed: onTap, child: Text(action)),
            ]),
          ),
        ),
      );
}

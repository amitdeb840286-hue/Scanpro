import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';

class ThemeModeNotifier extends Notifier<ThemeMode> {
  @override
  ThemeMode build() {
    _load();
    return ThemeMode.system;
  }

  Future<void> _load() async {
    final i = (await SharedPreferences.getInstance()).getInt('themeMode');
    if (i != null) state = ThemeMode.values[i];
  }

  Future<void> set(ThemeMode m) async {
    state = m;
    (await SharedPreferences.getInstance()).setInt('themeMode', m.index);
  }
}

class LocaleNotifier extends Notifier<Locale?> {
  @override
  Locale? build() {
    _load();
    return null; // null = follow system
  }

  Future<void> _load() async {
    final code = (await SharedPreferences.getInstance()).getString('locale');
    if (code != null) state = Locale(code);
  }

  Future<void> set(Locale? l) async {
    state = l;
    final p = await SharedPreferences.getInstance();
    l == null ? await p.remove('locale') : await p.setString('locale', l.languageCode);
  }
}

final themeModeProvider = NotifierProvider<ThemeModeNotifier, ThemeMode>(ThemeModeNotifier.new);
final localeProvider = NotifierProvider<LocaleNotifier, Locale?>(LocaleNotifier.new);

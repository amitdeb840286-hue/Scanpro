import 'package:flutter/material.dart';
import '../../l10n/app_localizations.dart';

/// Placeholder: merge/split/signature/annotation arrive in Step 5.
class ToolsScreen extends StatelessWidget {
  const ToolsScreen({super.key});
  @override
  Widget build(BuildContext context) {
    final l = AppLocalizations.of(context);
    return Scaffold(appBar: AppBar(title: Text(l.navTools)), body: Center(child: Text(l.toolsSoon)));
  }
}

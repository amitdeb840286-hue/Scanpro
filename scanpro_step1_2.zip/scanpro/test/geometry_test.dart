import 'dart:ui';
import 'package:flutter_test/flutter_test.dart';
import 'package:scanpro/core/utils/geometry.dart';

void main() {
  test('orderCorners returns TL, TR, BR, BL', () {
    final shuffled = [const Offset(0.9, 0.9), const Offset(0.1, 0.1), const Offset(0.1, 0.9), const Offset(0.9, 0.1)];
    expect(orderCorners(shuffled), [
      const Offset(0.1, 0.1), const Offset(0.9, 0.1), const Offset(0.9, 0.9), const Offset(0.1, 0.9),
    ]);
  });

  test('rotateNormalized 90 maps sensor corner to portrait corner', () {
    expect(rotateNormalized(const Offset(0, 0), 90), const Offset(1, 0));
    expect(rotateNormalized(const Offset(1, 0), 90), const Offset(1, 1));
    expect(rotateNormalized(const Offset(0.3, 0.7), 360), const Offset(0.3, 0.7));
  });

  test('maxCornerDelta is zero for identical quads', () {
    final q = defaultQuad();
    expect(maxCornerDelta(q, q), 0);
    expect(maxCornerDelta(q, defaultQuad(inset: 0.18)), greaterThan(0.1));
  });
}
